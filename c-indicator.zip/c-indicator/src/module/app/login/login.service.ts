/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { LoginDto } from '../dto/login.dto';

@Injectable()
export class LoginService {
  constructor(
   
  ) {}


  async adminLogin(loginDto: LoginDto): Promise<any> {
    try {
      let result;
     
        result = {
          status: true,
          message: 'Given Username or password is wrong.',
          data: null,
        };
      

      return result;
      // return user.length > 0 ? true : false;
    } catch (err) {
      throw err;
    }
  }

  }
