export default interface ResponseInterface {
  statusCode?: number;
  message?: string;
  data?: any;
}
