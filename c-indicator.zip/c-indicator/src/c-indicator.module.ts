/*
https://docs.nestjs.com/modules
*/

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoginController } from './module/app/login/login.controller';
import { LoginService } from './module/app/login/login.service';
@Module({
  imports: [
    TypeOrmModule.forFeature(
      [
        //Entity
      ],
    ),
  ],
  controllers: [
    // controller
    LoginController
  ],
  providers: [
    //service
    LoginService
  ],
})
export class CIndicator {}
